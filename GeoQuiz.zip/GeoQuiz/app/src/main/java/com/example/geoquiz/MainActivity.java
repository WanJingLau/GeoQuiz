package com.example.geoquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.geoquiz.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;

    private Question[] mQuestionsBank = new Question[]{
            new Question(R.string.question_ocean, true),
            new Question(R.string.question_mideast, false),
            new Question(R.string.question_africa, false),
            new Question(R.string.question_americas, true),
            new Question(R.string.question_asia, true)
    };

    private int mCurrentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View v = binding.getRoot();
        setContentView(v);

        //int question = mQuestionsBank[mCurrentIndex].getTextResId();
        //binding.questionTextView.setText(question);
        updateQuestion();

        binding.btnPrevious.setEnabled(false);

        binding.btnTrue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(MainActivity.this, R.string.correctToast, Toast.LENGTH_SHORT).show();
                checkAnswer(true);
            }
        });

        binding.btnFalse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(MainActivity.this, R.string.incorrectToast, Toast.LENGTH_SHORT).show();
                checkAnswer(false);
            }
        });

        binding.btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentIndex = (mCurrentIndex+1) % mQuestionsBank.length;
                //int question = mQuestionsBank[mCurrentIndex].getTextResId();
                //mQuestionTextView.setText(question);
                updateQuestion();

                if (mCurrentIndex+1 == mQuestionsBank.length){
                    binding.btnNext.setEnabled(false);
                }

                if (mCurrentIndex != 0){
                    binding.btnPrevious.setEnabled(true);
                }

            }
        });

        binding.btnPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentIndex = (mCurrentIndex-1) % mQuestionsBank.length;
                updateQuestion();

                if (mCurrentIndex != 0){
                    binding.btnPrevious.setEnabled(true);
                } else{
                    binding.btnNext.setEnabled(true);
                    binding.btnPrevious.setEnabled(false);
                }

                if (mCurrentIndex+1 != mQuestionsBank.length){
                    binding.btnNext.setEnabled(true);
                }
            }
        });

        Log.d("Main Activity", "Testing");
    }

    private void updateQuestion(){
        int question = mQuestionsBank[mCurrentIndex].getTextResId();
        binding.questionTextView.setText(question);
    }

    private void checkAnswer(boolean userPressedTrue){
        boolean answerIsTrue = mQuestionsBank[mCurrentIndex].isAnswerTrue();
        int messageResId = 0;
        if (userPressedTrue== answerIsTrue){
            messageResId = R.string.correctToast;
        }
        else{
            messageResId=R.string.incorrectToast;
        }
        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show();
    }

}

